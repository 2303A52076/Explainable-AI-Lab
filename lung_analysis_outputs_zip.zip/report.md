
# Auto-generated Lung Cancer Analysis Report
Dataset: /content/lung_cancer_dataset.csv
Rows,Cols: (50000, 11)
Detected target: lung_cancer
SMOTE applied: True
